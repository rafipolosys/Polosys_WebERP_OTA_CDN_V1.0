import{l as i}from"./index-BegUyK9R.js";const g=i("OTAPlugin");export{g as OTAPlugin};
