import{gd as g}from"./index-CQWkLOOS.js";const r=g("OTAPlugin");export{r as OTAPlugin};
