import{j as r,r as s}from"./index-CQWkLOOS.js";import{P as t}from"./parties-D8hCaYl9.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
