import{k as R,dU as E,r as d,aL as u,j as e,aj as I,U as N,al as y,au as z,A as L}from"./index-CQWkLOOS.js";const P=new L,F=()=>{const{t}=R("hr"),{getFormattedValue:v}=E(),[p,_]=d.useState(u().format("YYYY-MM")),[r,$]=d.useState(0),[s,w]=d.useState(null),[c,x]=d.useState(!1),[S,D]=d.useState(!1),i=u(p,"YYYY-MM"),Y=i.clone().startOf("month"),k=i.clone().endOf("month"),m=i.format("MMMM YYYY"),l=a=>v(a??0,!1,2),M=async()=>{if(!r||r<=0){z.show(t("please_select_employee"),"error");return}x(!0);try{const a=await P.postAsync(N.hr_salary_slip_report,{fromDate:Y.toDate(),toDate:k.toDate(),empID:r,monthYear:m}),n=(a==null?void 0:a.data)??[];w(n.length>0?n[0]:null),D(!0)}finally{x(!1)}},b=s?s.basicAmt+s.da+s.bonus+s.incentive:0,g=s?s.pf+s.esi+s.otherCut+s.spDeduction+s.loanAmount:0,j=s?[[1,t("basic"),s.basicAmt],[2,t("da"),s.da],[3,t("bonus_tip"),s.bonus],[4,t("incentive"),s.incentive]]:[],f=s?[[5,t("no_of_leave"),s.leaves],[6,t("sp_deduction"),s.spDeduction],[7,t("loan_amount"),s.loanAmount]]:[],A=()=>{if(!s)return;const a=C=>C.map(h=>`<tr><td>${h[0]}</td><td>${h[1]}</td><td class="amt">${l(h[2])}</td></tr>`).join(""),n=`
      <div class="hdr">
        <div class="big">${s.employeeName}</div>
        <div class="sub">${t("salary_slip_for")} ${m}</div>
      </div>
      <table class="kv">
        <tr><th>${t("employee_code")}</th><td>${s.employeeCode??""}</td></tr>
        <tr><th>${t("employee_name")}</th><td>${s.employeeName??""}</td></tr>
        <tr><th>${t("designation")}</th><td>${s.designationName??""}</td></tr>
      </table>
      <table class="pay">
        <thead><tr><th>${t("SiNo")}</th><th>${t("details")}</th><th class="amt">${t("amount")}</th></tr></thead>
        <tbody>
          <tr class="sec"><td colspan="3">${t("earnings")}</td></tr>
          ${a(j)}
          <tr class="tot"><td colspan="2">${t("total_gross_salary")}</td><td class="amt">${l(b)}</td></tr>
          <tr class="sec"><td colspan="3">${t("deductions")}</td></tr>
          ${a(f)}
          <tr class="tot"><td colspan="2">${t("total_gross_deduction")}</td><td class="amt">${l(g)}</td></tr>
          <tr class="net"><td colspan="2">${t("total_net_amount")}</td><td class="amt">${l(s.netSalary)}</td></tr>
        </tbody>
      </table>
      <div class="sign">${t("signature")}</div>`,o=window.open("","_blank");o&&(o.document.write(`<html><head><title>${t("salary_slip")} - ${s.employeeName}</title><style>
        body{font-family:Arial,sans-serif;padding:24px;color:#111}
        .hdr{text-align:center;margin-bottom:14px}
        .big{font-size:20px;font-weight:bold}
        .sub{font-size:14px;margin-top:4px}
        table{border-collapse:collapse;width:100%;margin-bottom:14px}
        .kv th,.kv td{border:1px solid #ccc;padding:5px 9px;font-size:13px;text-align:left}
        .pay th,.pay td{border:1px solid #ccc;padding:6px 9px;font-size:13px}
        .amt{text-align:right}
        .sec td{background:#eef2ff;font-weight:bold}
        .tot td{font-weight:bold;background:#f8fafc}
        .net td{font-weight:bold;background:#dcfce7}
        .sign{margin-top:60px;text-align:right;font-size:13px}
      </style></head><body>${n}</body></html>`),o.document.close(),o.focus(),o.print())};return e.jsx(d.Fragment,{children:e.jsx("div",{className:"p-4",children:e.jsxs("div",{className:"box",children:[e.jsxs("div",{className:"box-header flex flex-wrap items-center justify-between gap-3",children:[e.jsx("h5",{className:"box-title",children:t("salary_slip")}),e.jsxs("div",{className:"flex flex-wrap items-end gap-3",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-xs mb-1",children:t("month_year")}),e.jsx("input",{type:"month",value:p,onChange:a=>_(a.target.value),className:"ti-form-input rounded-sm border px-2 py-1"})]}),e.jsx("div",{className:"w-64",children:e.jsx(I,{id:"empID",label:t("employee"),value:r,field:{id:"empID",getListUrl:N.data_employees,valueKey:"id",labelKey:"name"},onSelectItem:a=>$((a==null?void 0:a.value)??0)})}),e.jsx(y,{variant:"primary",onClick:M,children:t("show")}),e.jsx(y,{variant:"secondary",onClick:A,disabled:!s,children:t("print")})]})]}),e.jsxs("div",{className:"box-body",children:[c&&e.jsxs("div",{className:"py-6 text-center",children:[t("loading"),"..."]}),!c&&S&&!s&&e.jsx("div",{className:"py-6 text-center text-gray-500",children:t("no_data_found")}),!c&&s&&e.jsxs("div",{className:"max-w-2xl mx-auto",children:[e.jsxs("div",{className:"text-center mb-4",children:[e.jsx("div",{className:"text-lg font-bold",children:s.employeeName}),e.jsxs("div",{className:"text-sm mt-1",children:[t("salary_slip_for")," ",m]})]}),e.jsx("table",{className:"w-full border-collapse mb-4 text-sm",children:e.jsxs("tbody",{children:[e.jsxs("tr",{className:"border-b",children:[e.jsx("th",{className:"text-left p-2 bg-gray-50 w-1/3",children:t("employee_code")}),e.jsx("td",{className:"p-2",children:s.employeeCode})]}),e.jsxs("tr",{className:"border-b",children:[e.jsx("th",{className:"text-left p-2 bg-gray-50",children:t("employee_name")}),e.jsx("td",{className:"p-2",children:s.employeeName})]}),e.jsxs("tr",{className:"border-b",children:[e.jsx("th",{className:"text-left p-2 bg-gray-50",children:t("designation")}),e.jsx("td",{className:"p-2",children:s.designationName})]})]})}),e.jsxs("table",{className:"w-full border-collapse text-sm",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-100",children:[e.jsx("th",{className:"border p-2 text-left w-16",children:t("SiNo")}),e.jsx("th",{className:"border p-2 text-left",children:t("details")}),e.jsx("th",{className:"border p-2 text-right w-40",children:t("amount")})]})}),e.jsxs("tbody",{children:[e.jsx("tr",{className:"bg-indigo-50 font-semibold",children:e.jsx("td",{className:"border p-2",colSpan:3,children:t("earnings")})}),j.map(a=>e.jsxs("tr",{className:"border-b",children:[e.jsx("td",{className:"border p-2",children:a[0]}),e.jsx("td",{className:"border p-2",children:a[1]}),e.jsx("td",{className:"border p-2 text-right",children:l(a[2])})]},`e${a[0]}`)),e.jsxs("tr",{className:"font-semibold bg-slate-50",children:[e.jsx("td",{className:"border p-2",colSpan:2,children:t("total_gross_salary")}),e.jsx("td",{className:"border p-2 text-right",children:l(b)})]}),e.jsx("tr",{className:"bg-indigo-50 font-semibold",children:e.jsx("td",{className:"border p-2",colSpan:3,children:t("deductions")})}),f.map(a=>e.jsxs("tr",{className:"border-b",children:[e.jsx("td",{className:"border p-2",children:a[0]}),e.jsx("td",{className:"border p-2",children:a[1]}),e.jsx("td",{className:"border p-2 text-right",children:l(a[2])})]},`d${a[0]}`)),e.jsxs("tr",{className:"font-semibold bg-slate-50",children:[e.jsx("td",{className:"border p-2",colSpan:2,children:t("total_gross_deduction")}),e.jsx("td",{className:"border p-2 text-right",children:l(g)})]}),e.jsxs("tr",{className:"font-bold bg-green-50",children:[e.jsx("td",{className:"border p-2",colSpan:2,children:t("total_net_amount")}),e.jsx("td",{className:"border p-2 text-right",children:l(s.netSalary)})]})]})]}),e.jsx("div",{className:"text-right mt-16 text-sm",children:t("signature")})]})]})]})})})};export{F as default};
