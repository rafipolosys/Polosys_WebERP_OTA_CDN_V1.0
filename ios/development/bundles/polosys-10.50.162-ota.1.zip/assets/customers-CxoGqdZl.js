import{j as r,r as t}from"./index-CQWkLOOS.js";import{P as s}from"./parties-D8hCaYl9.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
