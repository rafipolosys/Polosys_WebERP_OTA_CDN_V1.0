import{j as r,r as t}from"./index-ityhFc6X.js";import{P as s}from"./parties-BmWX9oBW.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
