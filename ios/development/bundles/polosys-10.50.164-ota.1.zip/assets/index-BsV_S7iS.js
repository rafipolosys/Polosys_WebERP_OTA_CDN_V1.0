const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DCbAo5z3.js","assets/index-ityhFc6X.js","assets/index-CEwzcXp9.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-ityhFc6X.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DCbAo5z3.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
