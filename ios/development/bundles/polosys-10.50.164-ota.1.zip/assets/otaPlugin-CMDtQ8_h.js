import{gd as g}from"./index-ityhFc6X.js";const r=g("OTAPlugin");export{r as OTAPlugin};
