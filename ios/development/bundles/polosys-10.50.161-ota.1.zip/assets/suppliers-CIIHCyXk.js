import{j as r,r as s}from"./index-CKqG7Ld8.js";import{P as t}from"./parties-87PIcgEK.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
