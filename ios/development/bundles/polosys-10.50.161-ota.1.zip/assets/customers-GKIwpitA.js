import{j as r,r as t}from"./index-CKqG7Ld8.js";import{P as s}from"./parties-87PIcgEK.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
