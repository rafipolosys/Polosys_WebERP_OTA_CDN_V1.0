import{gd as g}from"./index-CKqG7Ld8.js";const r=g("OTAPlugin");export{r as OTAPlugin};
