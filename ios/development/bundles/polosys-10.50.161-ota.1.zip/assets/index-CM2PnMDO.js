const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-sbJ_cQTq.js","assets/index-CKqG7Ld8.js","assets/index-D6ZveISM.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-CKqG7Ld8.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-sbJ_cQTq.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
