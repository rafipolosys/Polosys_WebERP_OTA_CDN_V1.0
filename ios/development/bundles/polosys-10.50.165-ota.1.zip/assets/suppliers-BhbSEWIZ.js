import{j as r,r as s}from"./index-BGfIskCc.js";import{P as t}from"./parties-SEBHpD6f.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
