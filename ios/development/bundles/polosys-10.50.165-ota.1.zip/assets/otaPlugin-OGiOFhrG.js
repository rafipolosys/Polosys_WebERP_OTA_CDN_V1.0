import{gd as g}from"./index-BGfIskCc.js";const r=g("OTAPlugin");export{r as OTAPlugin};
