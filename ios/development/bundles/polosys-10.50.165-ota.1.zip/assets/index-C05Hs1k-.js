const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DpBgGn1X.js","assets/index-BGfIskCc.js","assets/index-CF66knye.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-BGfIskCc.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DpBgGn1X.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
