const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-c3F6o2a9.js","assets/index-C7nJkQ-R.js","assets/index-CyPumNks.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-C7nJkQ-R.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-c3F6o2a9.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
