import{gd as g}from"./index-C7nJkQ-R.js";const r=g("OTAPlugin");export{r as OTAPlugin};
