import{j as r,r as t}from"./index-C7nJkQ-R.js";import{P as s}from"./parties-BJRqAKoG.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
