import{j as r,r as s}from"./index-qoW8djwH.js";import{P as t}from"./parties-BGqLjbZF.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
