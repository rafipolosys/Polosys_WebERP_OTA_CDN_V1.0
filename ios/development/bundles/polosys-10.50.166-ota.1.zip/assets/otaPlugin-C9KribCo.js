import{gd as g}from"./index-qoW8djwH.js";const r=g("OTAPlugin");export{r as OTAPlugin};
