const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index.esm-Cz3ZBYCY.js","assets/index-qoW8djwH.js","assets/index-C89kqM68.css"])))=>i.map(i=>d[i]);
import{_ as D,r as I,j as a}from"./index-qoW8djwH.js";const he=()=>{};var U={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const te=function(t){const e=[];let n=0;for(let r=0;r<t.length;r++){let s=t.charCodeAt(r);s<128?e[n++]=s:s<2048?(e[n++]=s>>6|192,e[n++]=s&63|128):(s&64512)===55296&&r+1<t.length&&(t.charCodeAt(r+1)&64512)===56320?(s=65536+((s&1023)<<10)+(t.charCodeAt(++r)&1023),e[n++]=s>>18|240,e[n++]=s>>12&63|128,e[n++]=s>>6&63|128,e[n++]=s&63|128):(e[n++]=s>>12|224,e[n++]=s>>6&63|128,e[n++]=s&63|128)}return e},ue=function(t){const e=[];let n=0,r=0;for(;n<t.length;){const s=t[n++];if(s<128)e[r++]=String.fromCharCode(s);else if(s>191&&s<224){const i=t[n++];e[r++]=String.fromCharCode((s&31)<<6|i&63)}else if(s>239&&s<365){const i=t[n++],o=t[n++],c=t[n++],l=((s&7)<<18|(i&63)<<12|(o&63)<<6|c&63)-65536;e[r++]=String.fromCharCode(55296+(l>>10)),e[r++]=String.fromCharCode(56320+(l&1023))}else{const i=t[n++],o=t[n++];e[r++]=String.fromCharCode((s&15)<<12|(i&63)<<6|o&63)}}return e.join("")},ne={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let s=0;s<t.length;s+=3){const i=t[s],o=s+1<t.length,c=o?t[s+1]:0,l=s+2<t.length,d=l?t[s+2]:0,m=i>>2,u=(i&3)<<4|c>>4;let g=(c&15)<<2|d>>6,f=d&63;l||(f=64,o||(g=64)),r.push(n[m],n[u],n[g],n[f])}return r.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(te(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):ue(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();const n=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let s=0;s<t.length;){const i=n[t.charAt(s++)],c=s<t.length?n[t.charAt(s)]:0;++s;const d=s<t.length?n[t.charAt(s)]:64;++s;const u=s<t.length?n[t.charAt(s)]:64;if(++s,i==null||c==null||d==null||u==null)throw new fe;const g=i<<2|c>>4;if(r.push(g),d!==64){const f=c<<4&240|d>>2;if(r.push(f),u!==64){const w=d<<6&192|u;r.push(w)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}};class fe extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const ge=function(t){const e=te(t);return ne.encodeByteArray(e,!0)},re=function(t){return ge(t).replace(/\./g,"")},me=function(t){try{return ne.decodeString(t,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pe(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const be=()=>pe().__FIREBASE_DEFAULTS__,ye=()=>{if(typeof process>"u"||typeof U>"u")return;const t=U.__FIREBASE_DEFAULTS__;if(t)return JSON.parse(t)},we=()=>{if(typeof document>"u")return;let t;try{t=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=t&&me(t[1]);return e&&JSON.parse(e)},Ee=()=>{try{return he()||be()||ye()||we()}catch(t){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${t}`);return}},se=()=>{var t;return(t=Ee())==null?void 0:t.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _e{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}wrapCallback(e){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(n):e(n,r))}}}function Ie(){try{return typeof indexedDB=="object"}catch{return!1}}function Ce(){return new Promise((t,e)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(r);s.onsuccess=()=>{s.result.close(),n||self.indexedDB.deleteDatabase(r),t(!0)},s.onupgradeneeded=()=>{n=!1},s.onerror=()=>{var i;e(((i=s.error)==null?void 0:i.message)||"")}}catch(n){e(n)}})}function Vt(){return!(typeof navigator>"u"||!navigator.cookieEnabled)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ve="FirebaseError";class v extends Error{constructor(e,n,r){super(n),this.code=e,this.customData=r,this.name=ve,Object.setPrototypeOf(this,v.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,ie.prototype.create)}}class ie{constructor(e,n,r){this.service=e,this.serviceName=n,this.errors=r}create(e,...n){const r=n[0]||{},s=`${this.service}/${e}`,i=this.errors[e],o=i?De(i,r):"Error",c=`${this.serviceName}: ${o} (${s}).`;return new v(s,c,r)}}function De(t,e){return t.replace(xe,(n,r)=>{const s=e[r];return s!=null?String(s):`<${r}?>`})}const xe=/\{\$([^}]+)}/g;function F(t,e){if(t===e)return!0;const n=Object.keys(t),r=Object.keys(e);for(const s of n){if(!r.includes(s))return!1;const i=t[s],o=e[s];if(W(i)&&W(o)){if(!F(i,o))return!1}else if(i!==o)return!1}for(const s of r)if(!n.includes(s))return!1;return!0}function W(t){return t!==null&&typeof t=="object"}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ut(t){return t&&t._delegate?t._delegate:t}class S{constructor(e,n,r){this.name=e,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Se{constructor(e,n){this.name=e,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const n=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(n)){const r=new _e;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:n});s&&r.resolve(s)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(e){const n=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(e==null?void 0:e.optional)??!1;if(this.isInitialized(n)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:n})}catch(s){if(r)return null;throw s}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Ne(e))try{this.getOrInitializeService({instanceIdentifier:_})}catch{}for(const[n,r]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(n);try{const i=this.getOrInitializeService({instanceIdentifier:s});r.resolve(i)}catch{}}}}clearInstance(e=_){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...e.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=_){return this.instances.has(e)}getOptions(e=_){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:n={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:r,options:n});for(const[i,o]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(i);r===c&&o.resolve(s)}return s}onInit(e,n){const r=this.normalizeInstanceIdentifier(n),s=this.onInitCallbacks.get(r)??new Set;s.add(e),this.onInitCallbacks.set(r,s);const i=this.instances.get(r);return i&&e(i,r),()=>{s.delete(e)}}invokeOnInitCallbacks(e,n){const r=this.onInitCallbacks.get(n);if(r)for(const s of r)try{s(e,n)}catch{}}getOrInitializeService({instanceIdentifier:e,options:n={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:Ae(e),options:n}),this.instances.set(e,r),this.instancesOptions.set(e,n),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=_){return this.component?this.component.multipleInstances?e:_:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Ae(t){return t===_?void 0:t}function Ne(t){return t.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Te{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const n=this.getProvider(e.name);if(n.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);n.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const n=new Se(e,this);return this.providers.set(e,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var h;(function(t){t[t.DEBUG=0]="DEBUG",t[t.VERBOSE=1]="VERBOSE",t[t.INFO=2]="INFO",t[t.WARN=3]="WARN",t[t.ERROR=4]="ERROR",t[t.SILENT=5]="SILENT"})(h||(h={}));const Me={debug:h.DEBUG,verbose:h.VERBOSE,info:h.INFO,warn:h.WARN,error:h.ERROR,silent:h.SILENT},Be=h.INFO,ke={[h.DEBUG]:"log",[h.VERBOSE]:"log",[h.INFO]:"info",[h.WARN]:"warn",[h.ERROR]:"error"},Fe=(t,e,...n)=>{if(e<t.logLevel)return;const r=new Date().toISOString(),s=ke[e];if(s)console[s](`[${r}]  ${t.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Oe{constructor(e){this.name=e,this._logLevel=Be,this._logHandler=Fe,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in h))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Me[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,h.DEBUG,...e),this._logHandler(this,h.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,h.VERBOSE,...e),this._logHandler(this,h.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,h.INFO,...e),this._logHandler(this,h.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,h.WARN,...e),this._logHandler(this,h.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,h.ERROR,...e),this._logHandler(this,h.ERROR,...e)}}const Re=(t,e)=>e.some(n=>t instanceof n);let G,J;function je(){return G||(G=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Pe(){return J||(J=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const oe=new WeakMap,O=new WeakMap,ae=new WeakMap,N=new WeakMap,z=new WeakMap;function $e(t){const e=new Promise((n,r)=>{const s=()=>{t.removeEventListener("success",i),t.removeEventListener("error",o)},i=()=>{n(b(t.result)),s()},o=()=>{r(t.error),s()};t.addEventListener("success",i),t.addEventListener("error",o)});return e.then(n=>{n instanceof IDBCursor&&oe.set(n,t)}).catch(()=>{}),z.set(e,t),e}function Le(t){if(O.has(t))return;const e=new Promise((n,r)=>{const s=()=>{t.removeEventListener("complete",i),t.removeEventListener("error",o),t.removeEventListener("abort",o)},i=()=>{n(),s()},o=()=>{r(t.error||new DOMException("AbortError","AbortError")),s()};t.addEventListener("complete",i),t.addEventListener("error",o),t.addEventListener("abort",o)});O.set(t,e)}let R={get(t,e,n){if(t instanceof IDBTransaction){if(e==="done")return O.get(t);if(e==="objectStoreNames")return t.objectStoreNames||ae.get(t);if(e==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return b(t[e])},set(t,e,n){return t[e]=n,!0},has(t,e){return t instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in t}};function He(t){R=t(R)}function ze(t){return t===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...n){const r=t.call(T(this),e,...n);return ae.set(r,e.sort?e.sort():[e]),b(r)}:Pe().includes(t)?function(...e){return t.apply(T(this),e),b(oe.get(this))}:function(...e){return b(t.apply(T(this),e))}}function Ve(t){return typeof t=="function"?ze(t):(t instanceof IDBTransaction&&Le(t),Re(t,je())?new Proxy(t,R):t)}function b(t){if(t instanceof IDBRequest)return $e(t);if(N.has(t))return N.get(t);const e=Ve(t);return e!==t&&(N.set(t,e),z.set(e,t)),e}const T=t=>z.get(t);function Ue(t,e,{blocked:n,upgrade:r,blocking:s,terminated:i}={}){const o=indexedDB.open(t,e),c=b(o);return r&&o.addEventListener("upgradeneeded",l=>{r(b(o.result),l.oldVersion,l.newVersion,b(o.transaction),l)}),n&&o.addEventListener("blocked",l=>n(l.oldVersion,l.newVersion,l)),c.then(l=>{i&&l.addEventListener("close",()=>i()),s&&l.addEventListener("versionchange",d=>s(d.oldVersion,d.newVersion,d))}).catch(()=>{}),c}function Wt(t,{blocked:e}={}){const n=indexedDB.deleteDatabase(t);return e&&n.addEventListener("blocked",r=>e(r.oldVersion,r)),b(n).then(()=>{})}const We=["get","getKey","getAll","getAllKeys","count"],Ge=["put","add","delete","clear"],M=new Map;function K(t,e){if(!(t instanceof IDBDatabase&&!(e in t)&&typeof e=="string"))return;if(M.get(e))return M.get(e);const n=e.replace(/FromIndex$/,""),r=e!==n,s=Ge.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(s||We.includes(n)))return;const i=async function(o,...c){const l=this.transaction(o,s?"readwrite":"readonly");let d=l.store;return r&&(d=d.index(c.shift())),(await Promise.all([d[n](...c),s&&l.done]))[0]};return M.set(e,i),i}He(t=>({...t,get:(e,n,r)=>K(e,n)||t.get(e,n,r),has:(e,n)=>!!K(e,n)||t.has(e,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Je{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(Ke(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function Ke(t){const e=t.getComponent();return(e==null?void 0:e.type)==="VERSION"}const j="@firebase/app",Y="0.14.3";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const y=new Oe("@firebase/app"),Ye="@firebase/app-compat",qe="@firebase/analytics-compat",Ze="@firebase/analytics",Xe="@firebase/app-check-compat",Qe="@firebase/app-check",et="@firebase/auth",tt="@firebase/auth-compat",nt="@firebase/database",rt="@firebase/data-connect",st="@firebase/database-compat",it="@firebase/functions",ot="@firebase/functions-compat",at="@firebase/installations",ct="@firebase/installations-compat",lt="@firebase/messaging",dt="@firebase/messaging-compat",ht="@firebase/performance",ut="@firebase/performance-compat",ft="@firebase/remote-config",gt="@firebase/remote-config-compat",mt="@firebase/storage",pt="@firebase/storage-compat",bt="@firebase/firestore",yt="@firebase/ai",wt="@firebase/firestore-compat",Et="firebase";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P="[DEFAULT]",_t={[j]:"fire-core",[Ye]:"fire-core-compat",[Ze]:"fire-analytics",[qe]:"fire-analytics-compat",[Qe]:"fire-app-check",[Xe]:"fire-app-check-compat",[et]:"fire-auth",[tt]:"fire-auth-compat",[nt]:"fire-rtdb",[rt]:"fire-data-connect",[st]:"fire-rtdb-compat",[it]:"fire-fn",[ot]:"fire-fn-compat",[at]:"fire-iid",[ct]:"fire-iid-compat",[lt]:"fire-fcm",[dt]:"fire-fcm-compat",[ht]:"fire-perf",[ut]:"fire-perf-compat",[ft]:"fire-rc",[gt]:"fire-rc-compat",[mt]:"fire-gcs",[pt]:"fire-gcs-compat",[bt]:"fire-fst",[wt]:"fire-fst-compat",[yt]:"fire-vertex","fire-js":"fire-js",[Et]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const A=new Map,It=new Map,$=new Map;function q(t,e){try{t.container.addComponent(e)}catch(n){y.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,n)}}function L(t){const e=t.name;if($.has(e))return y.debug(`There were multiple attempts to register component ${e}.`),!1;$.set(e,t);for(const n of A.values())q(n,t);for(const n of It.values())q(n,t);return!0}function Gt(t,e){const n=t.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),t.container.getProvider(e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ct={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},E=new ie("app","Firebase",Ct);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(e,n,r){this._isDeleted=!1,this._options={...e},this._config={...n},this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new S("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw E.create("app-deleted",{appName:this._name})}}function ce(t,e={}){let n=t;typeof e!="object"&&(e={name:e});const r={name:P,automaticDataCollectionEnabled:!0,...e},s=r.name;if(typeof s!="string"||!s)throw E.create("bad-app-name",{appName:String(s)});if(n||(n=se()),!n)throw E.create("no-options");const i=A.get(s);if(i){if(F(n,i.options)&&F(r,i.config))return i;throw E.create("duplicate-app",{appName:s})}const o=new Te(s);for(const l of $.values())o.addComponent(l);const c=new vt(n,r,o);return A.set(s,c),c}function Jt(t=P){const e=A.get(t);if(!e&&t===P&&se())return ce();if(!e)throw E.create("no-app",{appName:t});return e}function x(t,e,n){let r=_t[t]??t;n&&(r+=`-${n}`);const s=r.match(/\s|\//),i=e.match(/\s|\//);if(s||i){const o=[`Unable to register library "${r}" with version "${e}":`];s&&o.push(`library name "${r}" contains illegal characters (whitespace or "/")`),s&&i&&o.push("and"),i&&o.push(`version name "${e}" contains illegal characters (whitespace or "/")`),y.warn(o.join(" "));return}L(new S(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dt="firebase-heartbeat-database",xt=1,C="firebase-heartbeat-store";let B=null;function le(){return B||(B=Ue(Dt,xt,{upgrade:(t,e)=>{switch(e){case 0:try{t.createObjectStore(C)}catch(n){console.warn(n)}}}}).catch(t=>{throw E.create("idb-open",{originalErrorMessage:t.message})})),B}async function St(t){try{const n=(await le()).transaction(C),r=await n.objectStore(C).get(de(t));return await n.done,r}catch(e){if(e instanceof v)y.warn(e.message);else{const n=E.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});y.warn(n.message)}}}async function Z(t,e){try{const r=(await le()).transaction(C,"readwrite");await r.objectStore(C).put(e,de(t)),await r.done}catch(n){if(n instanceof v)y.warn(n.message);else{const r=E.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});y.warn(r.message)}}}function de(t){return`${t.name}!${t.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const At=1024,Nt=30;class Tt{constructor(e){this.container=e,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new Bt(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,n;try{const s=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=X();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((n=this._heartbeatsCache)==null?void 0:n.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(o=>o.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:s}),this._heartbeatsCache.heartbeats.length>Nt){const o=kt(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(o,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){y.warn(r)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const n=X(),{heartbeatsToSend:r,unsentEntries:s}=Mt(this._heartbeatsCache.heartbeats),i=re(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=n,s.length>0?(this._heartbeatsCache.heartbeats=s,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(n){return y.warn(n),""}}}function X(){return new Date().toISOString().substring(0,10)}function Mt(t,e=At){const n=[];let r=t.slice();for(const s of t){const i=n.find(o=>o.agent===s.agent);if(i){if(i.dates.push(s.date),Q(n)>e){i.dates.pop();break}}else if(n.push({agent:s.agent,dates:[s.date]}),Q(n)>e){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class Bt{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Ie()?Ce().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const n=await St(this.app);return n!=null&&n.heartbeats?n:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return Z(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return Z(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function Q(t){return re(JSON.stringify({version:2,heartbeats:t})).length}function kt(t){if(t.length===0)return-1;let e=0,n=t[0].date;for(let r=1;r<t.length;r++)t[r].date<n&&(n=t[r].date,e=r);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ft(t){L(new S("platform-logger",e=>new Je(e),"PRIVATE")),L(new S("heartbeat",e=>new Tt(e),"PRIVATE")),x(j,Y,t),x(j,Y,"esm2020"),x("fire-js","")}Ft("");var Ot="firebase",Rt="12.3.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */x(Ot,Rt,"app");const jt={apiKey:"AIzaSyDew0yCTc27JJ-U-qIvmEhvZ-cY38Es4uc",authDomain:"polotest-8acab.firebaseapp.com",projectId:"polotest-8acab",storageBucket:"polotest-8acab.firebasestorage.app",messagingSenderId:"464969509116",appId:"1:464969509116:web:5a80ce61b4f7a766ae8f79",measurementId:"G-LDT01JMLWP"},Pt="BHTFUhjeaCEZgOx2tMPJQFROxkwqWgHLJtIe28GkGR1pzda2JPfd-BiSTLyhxMO81CZWtXhT5xhVZqlIli_ksxM",k=ce(jt);let p=null;const $t=async()=>{var t,e;if(p)return console.log("✅ Using cached messaging instance"),p;try{console.log("🔧 Setting up Firebase messaging..."),console.log("User Agent:",navigator.userAgent);const n=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"||window.location.hostname==="0.0.0.0",r=navigator.userAgent.includes("wv")||!!((e=(t=window.go)==null?void 0:t.main)!=null&&e.App);if(n||r){console.log(n?"🏠 Running on localhost":"🖥️ Running in Wails WebView"),console.log("Using direct messaging setup (no service worker)");try{const{getMessaging:c}=await D(async()=>{const{getMessaging:l}=await import("./index.esm-Cz3ZBYCY.js");return{getMessaging:l}},__vite__mapDeps([0,1,2]));return p=c(k),console.log("✅ Firebase messaging initialized (direct mode)"),p}catch(c){return console.error("❌ Direct messaging setup failed:",c),p=null,null}}console.log("🌐 Production mode - setting up service worker...");const s=await navigator.serviceWorker.getRegistrations();for(const c of s)c.scope.includes("firebase-cloud-messaging")&&(console.log("🧹 Clearing existing FCM service worker"),await c.unregister());console.log("📝 Registering service worker...");const i=await Promise.race([navigator.serviceWorker.register("/firebase-messaging-sw.js",{scope:"/firebase-cloud-messaging-push-scope"}),new Promise((c,l)=>setTimeout(()=>l(new Error("Service worker registration timeout")),1e4))]);console.log("✅ Service Worker registered:",i),console.log("🚀 Initializing Firebase messaging...");const{getMessaging:o}=await D(async()=>{const{getMessaging:c}=await import("./index.esm-Cz3ZBYCY.js");return{getMessaging:c}},__vite__mapDeps([0,1,2]));return p=o(k),console.log("✅ Firebase messaging initialized"),p}catch(n){console.error("❌ Error setting up Firebase messaging:",n),console.log("🔄 Trying fallback messaging setup...");try{const{getMessaging:r}=await D(async()=>{const{getMessaging:s}=await import("./index.esm-Cz3ZBYCY.js");return{getMessaging:s}},__vite__mapDeps([0,1,2]));return p=r(k),console.log("✅ Fallback messaging initialized"),p}catch(r){return console.error("❌ Fallback messaging failed:",r),p=null,null}}};function ee(t,e){const n=new Promise((r,s)=>setTimeout(()=>s(new Error(`Operation timed out after ${e}ms`)),e));return Promise.race([t,n])}const H={fcmToken:null,isInitialized:!1,async init(){var t,e,n,r,s;if(console.log("🔄 Initializing NotificationService..."),console.log("Wails detected:",!!((e=(t=window.go)==null?void 0:t.main)!=null&&e.App)),console.log("User Agent:",navigator.userAgent),this.isInitialized)return console.log("✅ Already initialized, returning cached token:",this.fcmToken),this.fcmToken;try{const i=await $t();if(!i)return console.log("❌ Firebase messaging not available"),this.isInitialized=!0,null;if(console.log("🔐 Requesting notification permission..."),Notification.permission!=="granted"){const u=await ee(Notification.requestPermission(),5e3);if(u!=="granted")return console.log("❌ Notification permission denied:",u),this.isInitialized=!0,null}console.log("✅ Notification permission granted");const{getToken:o,onMessage:c}=await D(async()=>{const{getToken:u,onMessage:g}=await import("./index.esm-Cz3ZBYCY.js");return{getToken:u,onMessage:g}},__vite__mapDeps([0,1,2]));console.log("🎫 Getting FCM token...");let l=null,d=0;const m=3;for(;d<m&&!l;){d++,console.log(`🔄 Token attempt ${d}/${m}`);try{const u=window.location.hostname==="localhost"?8e3:15e3;if(l=await ee(o(i,{vapidKey:Pt}),u),l){console.log("✅ FCM Token received:",l.substring(0,20)+"..."),this.fcmToken=l;break}}catch(u){console.error(`❌ Token attempt ${d} failed:`,u),d<m&&(console.log("⏳ Waiting 1 second before retry..."),await new Promise(g=>setTimeout(g,1e3)))}}if(!l)console.error("❌ Failed to get FCM token after all attempts"),(s=(r=(n=window.go)==null?void 0:n.main)==null?void 0:r.App)!=null&&s.Notify&&console.log("🖥️ Wails environment detected, using native notifications as fallback");else{console.log("📨 Setting up message listener...");try{c(i,u=>{var w,V;console.log("📨 Foreground message received:",u);const g=((w=u.notification)==null?void 0:w.title)||"Notification",f=((V=u.notification)==null?void 0:V.body)||"";H.notify(g,f)}),console.log("✅ Message listener set up successfully")}catch(u){console.error("❌ Failed to set up message listener:",u)}}return this.isInitialized=!0,l}catch(i){return console.error("❌ FCM initialization error:",i),this.isInitialized=!0,null}},getToken(){return this.fcmToken},async refreshToken(){return console.log("🔄 Refreshing FCM token..."),this.isInitialized=!1,this.fcmToken=null,await this.init()},async notify(t,e){var n,r,s;if(console.log("🔔 Showing notification:",t,e),(s=(r=(n=window.go)==null?void 0:n.main)==null?void 0:r.App)!=null&&s.Notify){console.log("📱 Using Wails Go backend notification");try{await window.go.main.App.Notify(t,e);return}catch(i){console.error("❌ Wails notification error:",i)}}Notification.permission==="granted"?(console.log("🌐 Using web notification (FCM)"),new Notification(t,{body:e})):console.warn("⚠️ No notification method available")}},Lt=()=>{const[t,e]=I.useState(null),[n,r]=I.useState(!1),[s,i]=I.useState(!0),[o,c]=I.useState(null),[l,d]=I.useState("Starting..."),m=async()=>{i(!0),c(null);try{d("Initializing FCM..."),console.log("🚀 Starting FCM initialization...");const f=await H.init();if(e(f),f)d("✅ FCM Ready"),c(null);else{d("❌ FCM Failed");const w=window.location.hostname==="localhost";c(w?"FCM token not available on localhost. Try production build or use test notifications.":"Failed to get FCM token. Check console for details.")}}catch(f){console.error("FCM initialization error:",f),d("❌ Error"),c(f instanceof Error?f.message:"Unknown error occurred")}finally{i(!1)}};I.useEffect(()=>{m()},[]);const u=async f=>{try{await navigator.clipboard.writeText(f),r(!0),setTimeout(()=>r(!1),2e3),console.log("✅ Token copied to clipboard")}catch(w){console.error("❌ Failed to copy token:",w),c("Failed to copy token to clipboard")}},g=()=>{H.notify("🧪 Test Notification","This is a test message!")};return s?a.jsxs("div",{className:"p-6 bg-white rounded-lg shadow-md",children:[a.jsxs("h2",{className:"text-xl font-semibold mb-4",children:["🔄 ",l]}),a.jsxs("div",{className:"space-y-2",children:[a.jsx("div",{className:"animate-pulse bg-gray-200 h-4 rounded"}),a.jsx("div",{className:"animate-pulse bg-gray-200 h-4 rounded w-3/4"}),a.jsx("div",{className:"animate-pulse bg-gray-200 h-4 rounded w-1/2"})]}),a.jsx("p",{className:"text-sm text-gray-500 mt-4",children:"Setting up Firebase Cloud Messaging..."})]}):a.jsxs("div",{className:"p-6 bg-white rounded-lg shadow-md",children:[a.jsx("h2",{className:"text-xl font-semibold mb-4",children:"🔥 Firebase Cloud Messaging"}),a.jsxs("div",{className:"mb-4 p-3 bg-blue-50 rounded-md",children:[a.jsxs("h4",{className:"font-medium text-blue-800",children:["📊 Status: ",l]}),a.jsxs("p",{className:"text-blue-600 text-sm",children:["Environment: ",window.location.hostname==="localhost"?"Development (localhost)":"Production"]})]}),o&&a.jsxs("div",{className:"mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-md",children:[a.jsx("h3",{className:"text-yellow-800 font-medium",children:"⚠️ Notice"}),a.jsx("p",{className:"text-yellow-700 text-sm mt-1",children:o}),a.jsx("button",{onClick:m,className:"mt-2 px-3 py-1 bg-yellow-100 text-yellow-800 rounded text-sm hover:bg-yellow-200 transition-colors",children:"🔄 Retry"})]}),t?a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{children:[a.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-2",children:"🎫 FCM Token:"}),a.jsxs("div",{className:"relative",children:[a.jsx("textarea",{value:t,readOnly:!0,className:"w-full p-3 text-xs bg-gray-50 border border-gray-300 rounded-md font-mono resize-none",rows:4}),a.jsx("button",{onClick:()=>u(t),className:`absolute top-2 right-2 px-3 py-1 text-xs font-medium rounded-md transition-colors ${n?"bg-green-500 text-white":"bg-blue-500 text-white hover:bg-blue-600"}`,children:n?"✅ Copied!":"📋 Copy"})]})]}),a.jsxs("div",{className:"flex gap-2 flex-wrap",children:[a.jsx("button",{onClick:g,className:"px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors",children:"🔔 Test Notification"}),a.jsx("button",{onClick:()=>u(t),className:`px-4 py-2 rounded-md transition-colors ${n?"bg-green-500 text-white":"bg-gray-500 text-white hover:bg-gray-600"}`,children:n?"✅ Copied!":"📋 Copy Token"})]}),a.jsxs("div",{className:"p-4 bg-green-50 border border-green-200 rounded-md",children:[a.jsx("h4",{className:"font-medium text-green-800",children:"🎯 Send Push Notification"}),a.jsx("p",{className:"text-green-700 text-sm mt-1",children:"Token ready! Use Firebase Console → Cloud Messaging → Send test message"}),a.jsxs("p",{className:"text-green-600 text-xs mt-2",children:["Token length: ",t.length," characters"]})]})]}):a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{onClick:g,className:"px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors",children:"🔔 Test Local Notification"}),a.jsx("button",{onClick:m,className:"px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition-colors",children:"🔄 Retry FCM Setup"})]}),a.jsxs("div",{className:"p-4 bg-gray-50 border border-gray-200 rounded-md",children:[a.jsx("h4",{className:"font-medium text-gray-800",children:"💡 Tips"}),a.jsxs("ul",{className:"text-gray-600 text-sm mt-1 space-y-1",children:[a.jsx("li",{children:"• FCM tokens may not work on localhost in development"}),a.jsxs("li",{children:["• Try building for production: ",a.jsx("code",{className:"bg-gray-200 px-1 rounded",children:"npm run build"})]}),a.jsx("li",{children:"• Test notifications should still work locally"})]})]})]})]})},Ht=()=>a.jsx("main",{className:"min-h-screen bg-gray-100 py-10",children:a.jsxs("section",{className:"container mx-auto max-w-4xl px-4",children:[a.jsx("h1",{className:"text-3xl font-extrabold text-center mb-8 text-gray-900",children:"🚀 Wails + React + FCM Push Notification Test"}),a.jsx("div",{className:"bg-white shadow-md rounded-2xl p-6",children:a.jsx(Lt,{})})]})}),Kt=Object.freeze(Object.defineProperty({__proto__:null,default:Ht},Symbol.toStringTag,{value:"Module"}));export{S as C,ie as E,v as F,L as _,Gt as a,Jt as b,Vt as c,Wt as d,Kt as f,Ut as g,Ie as i,Ue as o,x as r,Ce as v};
