const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BfT7BMRe.js","assets/index-qoW8djwH.js","assets/index-C89kqM68.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-qoW8djwH.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BfT7BMRe.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
