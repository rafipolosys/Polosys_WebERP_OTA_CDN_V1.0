const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-eNI5l6u8.js","assets/index-ruEFG9Fc.js","assets/index-CF66knye.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-ruEFG9Fc.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-eNI5l6u8.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
