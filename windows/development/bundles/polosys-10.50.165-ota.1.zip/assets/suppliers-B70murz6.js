import{j as r,r as s}from"./index-ruEFG9Fc.js";import{P as t}from"./parties-D555C3FD.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
