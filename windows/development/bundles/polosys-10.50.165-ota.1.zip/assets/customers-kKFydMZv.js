import{j as r,r as t}from"./index-ruEFG9Fc.js";import{P as s}from"./parties-D555C3FD.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
