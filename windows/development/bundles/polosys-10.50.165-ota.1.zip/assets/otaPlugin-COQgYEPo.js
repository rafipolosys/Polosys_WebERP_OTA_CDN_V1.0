import{gd as g}from"./index-ruEFG9Fc.js";const r=g("OTAPlugin");export{r as OTAPlugin};
