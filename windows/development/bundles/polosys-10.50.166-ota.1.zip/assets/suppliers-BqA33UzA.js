import{j as r,r as s}from"./index-Dk_WWcmh.js";import{P as t}from"./parties-CQCc-Zfi.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
