import{gd as g}from"./index-Dk_WWcmh.js";const r=g("OTAPlugin");export{r as OTAPlugin};
