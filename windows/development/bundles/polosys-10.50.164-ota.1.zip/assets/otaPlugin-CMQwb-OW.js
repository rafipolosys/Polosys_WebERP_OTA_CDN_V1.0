import{gd as g}from"./index-BERUxIo_.js";const r=g("OTAPlugin");export{r as OTAPlugin};
