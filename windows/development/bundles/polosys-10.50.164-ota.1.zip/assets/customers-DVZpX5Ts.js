import{j as r,r as t}from"./index-BERUxIo_.js";import{P as s}from"./parties-Dle_14W6.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
