import{j as r,r as s}from"./index-DAVZG9JU.js";import{P as t}from"./parties-rHu7vs0j.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
