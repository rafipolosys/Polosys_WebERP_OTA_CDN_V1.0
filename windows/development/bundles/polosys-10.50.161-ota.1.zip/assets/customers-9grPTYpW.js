import{j as r,r as t}from"./index-DAVZG9JU.js";import{P as s}from"./parties-rHu7vs0j.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
