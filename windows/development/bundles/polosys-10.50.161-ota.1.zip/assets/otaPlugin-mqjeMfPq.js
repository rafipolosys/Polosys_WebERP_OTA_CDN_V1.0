import{gd as g}from"./index-DAVZG9JU.js";const r=g("OTAPlugin");export{r as OTAPlugin};
