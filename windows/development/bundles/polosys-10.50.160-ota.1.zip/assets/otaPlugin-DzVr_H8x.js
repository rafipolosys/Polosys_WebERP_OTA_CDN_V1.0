import{l as i}from"./index-CFLaG5Ju.js";const g=i("OTAPlugin");export{g as OTAPlugin};
