import{j as r,r as t}from"./index-CFLaG5Ju.js";import{P as s}from"./parties-Buz3h4cV.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
