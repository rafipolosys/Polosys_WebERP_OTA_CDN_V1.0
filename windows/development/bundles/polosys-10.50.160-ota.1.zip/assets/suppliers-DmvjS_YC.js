import{j as r,r as s}from"./index-CFLaG5Ju.js";import{P as t}from"./parties-Buz3h4cV.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
