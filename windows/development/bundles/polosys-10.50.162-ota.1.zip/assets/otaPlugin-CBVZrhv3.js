import{gd as g}from"./index-CZVAzxBE.js";const r=g("OTAPlugin");export{r as OTAPlugin};
