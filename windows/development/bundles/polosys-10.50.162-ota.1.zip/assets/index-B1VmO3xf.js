const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DWPvudsR.js","assets/index-CZVAzxBE.js","assets/index-D6ZveISM.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-CZVAzxBE.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DWPvudsR.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
