const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BnkWpXOU.js","assets/index-Ddw8a_bW.js","assets/index-CyPumNks.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-Ddw8a_bW.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BnkWpXOU.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
