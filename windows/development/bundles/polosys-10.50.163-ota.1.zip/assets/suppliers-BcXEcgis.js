import{j as r,r as s}from"./index-Ddw8a_bW.js";import{P as t}from"./parties-VWET-6TT.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
