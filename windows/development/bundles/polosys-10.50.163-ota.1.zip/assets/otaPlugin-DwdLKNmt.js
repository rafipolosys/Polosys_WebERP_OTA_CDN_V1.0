import{gd as g}from"./index-Ddw8a_bW.js";const r=g("OTAPlugin");export{r as OTAPlugin};
