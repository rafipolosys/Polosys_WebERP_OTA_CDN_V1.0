import{j as r,r as t}from"./index-Ddw8a_bW.js";import{P as s}from"./parties-VWET-6TT.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
