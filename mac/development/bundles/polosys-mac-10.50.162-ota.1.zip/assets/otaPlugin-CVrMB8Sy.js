import{gd as g}from"./index--BGHIS7q.js";const r=g("OTAPlugin");export{r as OTAPlugin};
