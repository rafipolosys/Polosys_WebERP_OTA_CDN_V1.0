import{j as r,r as t}from"./index--BGHIS7q.js";import{P as s}from"./parties-us6pH_Bo.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
