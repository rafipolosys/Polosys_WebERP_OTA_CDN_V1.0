import{j as r,r as s}from"./index--BGHIS7q.js";import{P as t}from"./parties-us6pH_Bo.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
