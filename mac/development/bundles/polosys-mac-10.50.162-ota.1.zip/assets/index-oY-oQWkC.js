const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-67TVBQp0.js","assets/index--BGHIS7q.js","assets/index-D6ZveISM.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index--BGHIS7q.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-67TVBQp0.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
