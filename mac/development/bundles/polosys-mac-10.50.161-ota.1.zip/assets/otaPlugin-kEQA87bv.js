import{gd as g}from"./index-CKjYbrrd.js";const r=g("OTAPlugin");export{r as OTAPlugin};
