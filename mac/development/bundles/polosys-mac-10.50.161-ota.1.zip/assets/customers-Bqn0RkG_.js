import{j as r,r as t}from"./index-CKjYbrrd.js";import{P as s}from"./parties-CQC5xOsX.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
