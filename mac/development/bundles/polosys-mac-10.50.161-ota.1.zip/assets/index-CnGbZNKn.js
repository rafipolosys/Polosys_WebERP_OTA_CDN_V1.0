const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BiaCU9an.js","assets/index-CKjYbrrd.js","assets/index-D6ZveISM.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-CKjYbrrd.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BiaCU9an.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
