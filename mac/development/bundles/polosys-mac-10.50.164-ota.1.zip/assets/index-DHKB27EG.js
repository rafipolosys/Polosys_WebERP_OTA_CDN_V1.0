const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BU0Eu-bg.js","assets/index-sGQSUJ2P.js","assets/index-CEwzcXp9.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-sGQSUJ2P.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BU0Eu-bg.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
