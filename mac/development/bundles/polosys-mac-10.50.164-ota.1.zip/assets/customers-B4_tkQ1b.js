import{j as r,r as t}from"./index-sGQSUJ2P.js";import{P as s}from"./parties-B2aw_5Hz.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
