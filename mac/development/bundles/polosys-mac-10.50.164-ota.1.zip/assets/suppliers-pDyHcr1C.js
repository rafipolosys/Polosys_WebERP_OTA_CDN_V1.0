import{j as r,r as s}from"./index-sGQSUJ2P.js";import{P as t}from"./parties-B2aw_5Hz.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
