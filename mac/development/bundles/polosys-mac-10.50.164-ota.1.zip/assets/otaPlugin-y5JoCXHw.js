import{gd as g}from"./index-sGQSUJ2P.js";const r=g("OTAPlugin");export{r as OTAPlugin};
