import{j as r,r as t}from"./index-SBFsvVyp.js";import{P as s}from"./parties-L5LwSeFC.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
