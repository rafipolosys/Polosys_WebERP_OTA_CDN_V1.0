import{gd as g}from"./index-SBFsvVyp.js";const r=g("OTAPlugin");export{r as OTAPlugin};
