import{j as r,r as s}from"./index-DnRD_62k.js";import{P as t}from"./parties-C55u-MiJ.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
