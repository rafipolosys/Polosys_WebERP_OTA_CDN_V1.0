import{j as r,r as t}from"./index-DnRD_62k.js";import{P as s}from"./parties-C55u-MiJ.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
