import{l as i}from"./index-DnRD_62k.js";const g=i("OTAPlugin");export{g as OTAPlugin};
