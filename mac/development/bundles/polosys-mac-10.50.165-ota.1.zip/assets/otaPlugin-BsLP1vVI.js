import{gd as g}from"./index-DC-wIwfE.js";const r=g("OTAPlugin");export{r as OTAPlugin};
