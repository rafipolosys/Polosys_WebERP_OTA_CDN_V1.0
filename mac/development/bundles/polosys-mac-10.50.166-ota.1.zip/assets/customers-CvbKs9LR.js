import{j as r,r as t}from"./index-CIq7vgi-.js";import{P as s}from"./parties-BKh65sY2.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
