import{gd as g}from"./index-CIq7vgi-.js";const r=g("OTAPlugin");export{r as OTAPlugin};
