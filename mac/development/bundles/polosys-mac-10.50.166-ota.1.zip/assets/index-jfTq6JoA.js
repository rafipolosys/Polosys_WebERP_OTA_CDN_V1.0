const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DtY-DLi-.js","assets/index-CIq7vgi-.js","assets/index-C89kqM68.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-CIq7vgi-.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DtY-DLi-.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
