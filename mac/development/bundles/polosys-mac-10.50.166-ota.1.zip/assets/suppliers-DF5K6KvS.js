import{j as r,r as s}from"./index-CIq7vgi-.js";import{P as t}from"./parties-BKh65sY2.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
