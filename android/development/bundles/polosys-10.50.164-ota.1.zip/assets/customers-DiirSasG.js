import{j as r,r as t}from"./index-7TOalrGK.js";import{P as s}from"./parties-DFH2gGOD.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
