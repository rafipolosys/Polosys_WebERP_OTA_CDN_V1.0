import{gd as g}from"./index-7TOalrGK.js";const r=g("OTAPlugin");export{r as OTAPlugin};
