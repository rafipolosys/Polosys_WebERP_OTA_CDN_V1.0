import{j as r,r as s}from"./index-7TOalrGK.js";import{P as t}from"./parties-DFH2gGOD.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
