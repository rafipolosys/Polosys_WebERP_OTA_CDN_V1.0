const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CCC6HmdO.js","assets/index-7TOalrGK.js","assets/index-CEwzcXp9.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-7TOalrGK.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CCC6HmdO.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
