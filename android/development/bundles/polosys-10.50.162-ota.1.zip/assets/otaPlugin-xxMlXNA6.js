import{gd as g}from"./index-CHfx7ZI2.js";const r=g("OTAPlugin");export{r as OTAPlugin};
