const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BzIiWPHM.js","assets/index-CHfx7ZI2.js","assets/index-D6ZveISM.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-CHfx7ZI2.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BzIiWPHM.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
