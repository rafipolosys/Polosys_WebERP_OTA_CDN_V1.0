import{j as r,r as t}from"./index-CHfx7ZI2.js";import{P as s}from"./parties-DgOJXyy0.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
