import{j as r,r as s}from"./index-B5JuaVkO.js";import{P as t}from"./parties-Dm0aXC28.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
