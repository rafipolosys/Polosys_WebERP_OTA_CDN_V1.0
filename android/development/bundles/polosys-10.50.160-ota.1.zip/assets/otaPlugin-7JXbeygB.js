import{l as i}from"./index-B5JuaVkO.js";const g=i("OTAPlugin");export{g as OTAPlugin};
