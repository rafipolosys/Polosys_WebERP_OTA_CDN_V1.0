import{j as r,r as t}from"./index-B5JuaVkO.js";import{P as s}from"./parties-Dm0aXC28.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
