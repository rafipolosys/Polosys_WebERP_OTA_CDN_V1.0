import{gd as g}from"./index-C6y6e7gu.js";const r=g("OTAPlugin");export{r as OTAPlugin};
