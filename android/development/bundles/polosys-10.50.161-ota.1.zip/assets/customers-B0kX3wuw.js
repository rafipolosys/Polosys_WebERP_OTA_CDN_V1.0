import{j as r,r as t}from"./index-C6y6e7gu.js";import{P as s}from"./parties-D0l6hlA1.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
