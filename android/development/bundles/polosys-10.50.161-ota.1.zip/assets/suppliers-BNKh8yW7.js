import{j as r,r as s}from"./index-C6y6e7gu.js";import{P as t}from"./parties-D0l6hlA1.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
