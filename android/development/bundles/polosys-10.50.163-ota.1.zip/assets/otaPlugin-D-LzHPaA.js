import{gd as g}from"./index-CWuO6cN3.js";const r=g("OTAPlugin");export{r as OTAPlugin};
