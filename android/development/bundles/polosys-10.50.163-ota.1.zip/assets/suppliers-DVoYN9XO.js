import{j as r,r as s}from"./index-CWuO6cN3.js";import{P as t}from"./parties-Cze-01uL.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
