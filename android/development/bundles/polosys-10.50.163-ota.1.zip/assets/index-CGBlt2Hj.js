const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BLehTQtz.js","assets/index-CWuO6cN3.js","assets/index-CyPumNks.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-CWuO6cN3.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BLehTQtz.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
