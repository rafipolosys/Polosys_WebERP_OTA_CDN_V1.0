import{j as r,r as t}from"./index-CWuO6cN3.js";import{P as s}from"./parties-Cze-01uL.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
