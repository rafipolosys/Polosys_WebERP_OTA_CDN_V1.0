import{gd as g}from"./index-UdRvIxsZ.js";const r=g("OTAPlugin");export{r as OTAPlugin};
