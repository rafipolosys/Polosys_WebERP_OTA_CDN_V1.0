import{j as r,r as s}from"./index-P7W9IIsm.js";import{P as t}from"./parties-Dmw76oZc.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
