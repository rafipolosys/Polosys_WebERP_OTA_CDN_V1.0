import{gd as g}from"./index-P7W9IIsm.js";const r=g("OTAPlugin");export{r as OTAPlugin};
