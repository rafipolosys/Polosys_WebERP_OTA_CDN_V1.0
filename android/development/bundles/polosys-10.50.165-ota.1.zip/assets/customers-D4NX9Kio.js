import{j as r,r as t}from"./index-P7W9IIsm.js";import{P as s}from"./parties-Dmw76oZc.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
