const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CbN1JJc6.js","assets/index-DvVTDkYP.js","assets/index-CEwzcXp9.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-DvVTDkYP.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CbN1JJc6.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
