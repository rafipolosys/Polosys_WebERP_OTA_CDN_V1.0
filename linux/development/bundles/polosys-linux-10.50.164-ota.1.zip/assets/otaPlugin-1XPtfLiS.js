import{gd as g}from"./index-DvVTDkYP.js";const r=g("OTAPlugin");export{r as OTAPlugin};
