import{j as r,r as s}from"./index-DvVTDkYP.js";import{P as t}from"./parties-CyEQtLiM.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
