import{j as r,r as t}from"./index-CsZYa_88.js";import{P as s}from"./parties-B7rrm2aY.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
