import{j as r,r as s}from"./index-CsZYa_88.js";import{P as t}from"./parties-B7rrm2aY.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
