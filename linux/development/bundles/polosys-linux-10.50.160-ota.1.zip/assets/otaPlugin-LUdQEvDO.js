import{l as i}from"./index-CsZYa_88.js";const g=i("OTAPlugin");export{g as OTAPlugin};
