const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CMtvRntD.js","assets/index-D_CNjDZo.js","assets/index-CF66knye.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-D_CNjDZo.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CMtvRntD.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
