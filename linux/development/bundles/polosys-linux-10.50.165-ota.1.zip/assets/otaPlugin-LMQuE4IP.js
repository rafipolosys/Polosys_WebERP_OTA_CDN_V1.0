import{gd as g}from"./index-D_CNjDZo.js";const r=g("OTAPlugin");export{r as OTAPlugin};
