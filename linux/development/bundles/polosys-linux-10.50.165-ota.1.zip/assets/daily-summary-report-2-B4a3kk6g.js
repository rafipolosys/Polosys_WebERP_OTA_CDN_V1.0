import{aL as v,k as T,j as a,aj as K,ay as S,dU as L,a as P,r as n,n3 as $,nh as q,A as B,U as W,au as J,h as U,n7 as Q,ni as X,nj as Z,nk as ee,nl as te,nm as ae,n4 as re,nn as oe,no as ie}from"./index-D_CNjDZo.js";import{S as de,e as le}from"./export_pivot_grid-Cq8rWKDS.js";const se=({getFieldProps:e,handleFieldChange:m})=>{const{t:u}=T("accountsReport");return a.jsxs("div",{className:"grid grid-cols-1 gap-4 overflow-y-hidden overflow-x-hidden",children:[a.jsx(K,{label:u("select_report"),...e("reportOf"),options:[{value:"week_daywise",label:u("week_day_wise_report")}],field:{id:"reportOf",valueKey:"value",labelKey:"label"},onSelectItem:c=>m("reportOf",c.value)}),a.jsxs("div",{className:"flex flex-col sm:flex-row items-start sm:items-center gap-2",children:[a.jsx(S,{label:u("from_date"),...e("fromDate"),className:"w-full",onChangeData:c=>m("fromDate",c.fromDate)}),a.jsx(S,{label:u("to_date"),...e("toDate"),className:"w-full",onChangeData:c=>m("toDate",c.toDate)})]})]})},k={reportOf:"week_daywise",fromDate:v().local().subtract(7,"days").toDate(),toDate:v().local().toDate()},R={January:1,February:2,March:3,April:4,May:5,June:6,July:7,August:8,September:9,October:10,November:11,December:12},C={Sunday:1,Monday:2,Tuesday:3,Wednesday:4,Thursday:5,Friday:6,Saturday:7},ne="grd_rpos_daily_summary_report_2",E="grd_rpos_daily_summary_report_2_v2",ce=e=>(e||"Report").replace(/[\\/*?:\[\]]/g," ").substring(0,31).trim()||"Report",pe=new B,xe=()=>{const{t:e}=T("accountsReport"),{getFormattedValue:m}=L(),u=P(t=>{var o;return(o=t==null?void 0:t.AppState)==null?void 0:o.appState}),c=n.useRef(null),[x,A]=n.useState(k),[F,w]=n.useState([]),[M,D]=n.useState(!1),[O,y]=n.useState(!1),_=n.useCallback(async t=>{D(!0);try{const o=$(q(t,k,{defaultNumber:null})),r=await pe.postAsync(W.restaurant_week_daywise,o);(r==null?void 0:r.isOk)===!1?(J.show(r.message,"error"),w([])):w(Array.isArray(r)?r:(r==null?void 0:r.data)??[])}catch(o){console.error("DSR 2 load failed:",o),w([])}finally{D(!1)}},[]);n.useEffect(()=>{_(k)},[_]);const j=n.useCallback(t=>t==null||isNaN(t)?"":m(t)||"",[m]),Y=n.useCallback(t=>t==null||isNaN(t)?"":m(t,!1,2)||"",[m]),V=n.useMemo(()=>{const t=(r,d)=>({dataField:r,caption:d,dataType:"string",area:"filter",expanded:!0}),o=(r,d,b)=>({dataField:r,caption:d,dataType:"number",summaryType:"sum",format:r=="qty"?Y:j,area:b});return{retrieveFields:!1,store:F,fields:[{dataField:"pCode",caption:e("product_code"),area:"row",expanded:!0},{dataField:"product",caption:e("product_name"),area:"row",expanded:!0},{dataField:"weekName",caption:e("week_name"),area:"column",expanded:!0,sortingMethod:(r,d)=>(C[r.value]??8)-(C[d.value]??8)},o("qty",e("qty"),"data"),o("total",e("total"),"data"),t("warehouse",e("warehouse")),t("brand",e("brand")),t("branch",e("branch_name")),t("groupName",e("group_name")),t("batch",e("batch")),t("unit",e("unit_name")),{dataField:"date",caption:e("date"),dataType:"date",area:"filter",expanded:!0},t("voucherNumber",e("voucher_number")),{dataField:"year",caption:e("year"),dataType:"number",area:"filter",expanded:!0},{dataField:"month",caption:e("month"),area:"filter",expanded:!0,sortingMethod:(r,d)=>(R[r.value]??13)-(R[d.value]??13)},{dataField:"weekNumber",caption:e("week_number"),dataType:"number",area:"filter",expanded:!0},o("cost",e("cost"),"filter")]}},[F,e,j]),z=n.useMemo(()=>`${e("week_day_wise_report")} From: ${v(x==null?void 0:x.fromDate).format("DD/MMM/YYYY")} - ${v(x==null?void 0:x.toDate).format("DD/MMM/YYYY")}`,[x,e]),G=t=>{y(!1),A(t),_(t)},H=()=>{var b;const t=(b=c.current)==null?void 0:b.instance();if(!t)return;const o=new oe.Workbook,r=ce(e("daily_summary_report_dsr2")),d=o.addWorksheet(r);le({component:t,worksheet:d,exportRowFieldHeaders:!0,exportColumnFieldHeaders:!0,customizeCell:g=>{const s=g.excelCell||g.cell,l=g.pivotCell||g.gridCell;if(!(!s||!l))if(l.area==="data"){const f=l.text;if(f!=null&&f!==""){const i=String(f).replace(/,/g,"").trim(),h=parseFloat(i);if(isNaN(h))s.value=f;else{s.value=h;const p=i.indexOf("."),N=p>=0?i.length-p-1:0;s.numFmt=N>0?`#,##0.${"0".repeat(N)}`:"#,##0"}}else s.value=""}else l.area==="row"&&typeof s.value=="string"&&(s.numFmt="@")}}).then(()=>{var f;const g=d.actualColumnCount;let s=d.getRow(3);for(let i=2;i<=5;i++){const h=d.getRow(i).getCell(g-2).value;if(h===e("total")||h==="Total"){s=d.getRow(i);break}}const l=s.getCell(g-2);[e("qty"),e("total")].forEach((i,h)=>{const p=s.getCell(g-1+h);p.value||(p.value=i,l.font&&(p.font=l.font),l.alignment&&(p.alignment=l.alignment),l.border&&(p.border=l.border),l.fill&&(p.fill=l.fill))}),(f=d.columns)==null||f.forEach(i=>{(!i.width||i.width<12)&&(i.width=12)}),o.xlsx.writeBuffer().then(i=>{ie.saveAs(new Blob([i],{type:"application/octet-stream"}),`${r}.xlsx`)})})},I=()=>{var t,o,r;try{localStorage.removeItem(E)}catch{}(r=(o=(t=c.current)==null?void 0:t.instance())==null?void 0:o.getDataSource())==null||r.state({})};return a.jsx("div",{className:"grid grid-cols-12 gap-x-6",children:a.jsx("div",{className:"col-span-12",children:a.jsx("div",{className:"px-4 pt-4 pb-2",children:a.jsxs("div",{className:"grid grid-cols-1 gap-3",children:[a.jsxs("div",{className:"flex items-center justify-between gap-2 flex-wrap",children:[a.jsx("span",{className:"font-semibold dark:text-dark-text",children:z}),a.jsxs("div",{className:"flex items-center gap-1",children:[a.jsx("button",{className:"ti-btn dark:bg-dark-bg-header dark:text-dark-text rounded-[2px]",title:e("reset",{defaultValue:"Reset Layout"}),onClick:I,children:a.jsx(U,{className:"w-4 h-4"})}),a.jsx("button",{className:"ti-btn dark:bg-dark-bg-header dark:text-dark-text rounded-[2px]",title:"Excel",onClick:H,children:a.jsx(de,{className:"w-4 h-4"})}),a.jsx("button",{className:"ti-btn dark:bg-dark-bg-header dark:text-dark-text rounded-[2px]",title:e("filter",{defaultValue:"Filter"}),onClick:()=>y(t=>!t),children:a.jsx(Q,{className:"w-4 h-4"})})]})]}),a.jsxs("div",{className:"relative erp-pivot-grid dsr2-pivot-grid",children:[a.jsx("style",{children:`
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell {
                  padding: 0 !important;
                  vertical-align: middle !important;
                  background-color: #f8fafc;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-pivotgrid-fields-area {
                  height: 100%;
                  display: flex;
                  flex-direction: column;
                  justify-content: stretch;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field-container {
                  width: 100% !important;
                  height: 100% !important;
                  border-collapse: collapse !important;
                  table-layout: fixed !important;
                  margin: 0 !important;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-pivotgrid-fields-area-head {
                  height: 100%;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-pivotgrid-fields-area-head tr {
                  height: 100%;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-pivotgrid-fields-area-head td {
                  padding: 0 !important;
                  border: none !important;
                  border-inline-end: 1px solid #e2e8f0 !important;
                  height: 100%;
                  vertical-align: middle !important;
                  position: relative;
                  background-color: #f8fafc;
                  box-sizing: border-box;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-pivotgrid-fields-area-head td:last-child {
                  border-inline-end: none !important;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field.dx-area-box {
                  margin: 0 !important;
                  border: none !important;
                  border-radius: 0 !important;
                  background: transparent !important;
                  box-shadow: none !important;
                  width: 100% !important;
                  height: 100% !important;
                  min-height: 32px;
                  display: flex !important;
                  align-items: center !important;
                  justify-content: center !important;
                  position: relative !important;
                  padding: 6px 14px !important;
                  box-sizing: border-box !important;
                  font-size: 13px !important;
                  font-weight: 600 !important;
                  color: #334155;
                  cursor: pointer;
                  transition: background-color 0.15s ease;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field.dx-area-box:hover {
                  background-color: rgba(0, 0, 0, 0.04) !important;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field.dx-area-box:hover .dx-column-indicators {
                  opacity: 1 !important;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field-content {
                  font-weight: 600 !important;
                  font-size: 13px !important;
                  white-space: nowrap !important;
                  overflow: hidden !important;
                  text-overflow: ellipsis !important;
                  text-align: center !important;
                }
                .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-column-indicators {
                  position: absolute !important;
                  right: 6px !important;
                  display: inline-flex !important;
                  align-items: center !important;
                  gap: 3px !important;
                  line-height: 1 !important;
                  opacity: 0.5;
                  transition: opacity 0.15s ease;
                }
                .dark .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell {
                  background-color: #1e1e1f !important;
                }
                .dark .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-pivotgrid-fields-area-head td {
                  border-color: #f2f4f538 !important;
                  background-color: #1e1e1f !important;
                }
                .dark .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field.dx-area-box {
                  color: #e0e0e0 !important;
                  background: transparent !important;
                }
                .dark .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field.dx-area-box:hover {
                  background-color: rgba(255, 255, 255, 0.05) !important;
                }
                .dark .dsr2-pivot-grid .dx-pivotgrid .dx-area-description-cell .dx-area-field-content {
                  color: #e0e0e0 !important;
                }
              `}),M&&a.jsx("div",{className:"absolute inset-0 z-10 flex items-center justify-center bg-white/60 dark:bg-black/40",children:a.jsx("span",{className:"dark:text-dark-text",children:e("loading",{defaultValue:"Loading..."})})}),a.jsxs(X,{ref:c,dataSource:V,rowHeaderLayout:"standard",allowSortingBySummary:!0,allowSorting:!0,allowFiltering:!0,allowExpandAll:!0,showBorders:!0,showColumnGrandTotals:!0,showRowGrandTotals:!0,showColumnTotals:!0,showRowTotals:!1,rtlEnabled:(u==null?void 0:u.dir)==="rtl",height:"calc(100vh / var(--app-zoom, 1) - 220px)",texts:{grandTotal:e("grand_total",{defaultValue:"Grand Total"})},children:[a.jsx(Z,{mode:"standard"}),a.jsx(ee,{visible:!0,allowFieldDragging:!0,showColumnFields:!0,showDataFields:!0,showFilterFields:!0,showRowFields:!0,texts:{columnFieldArea:e("drop_column_fields_here",{defaultValue:"Drop Column Fields Here"}),dataFieldArea:e("drop_data_fields_here",{defaultValue:"Drop Data Fields Here"}),filterFieldArea:e("drop_filter_fields_here",{defaultValue:"Drop Filter Fields Here"}),rowFieldArea:e("drop_row_fields_here",{defaultValue:"Drop Row Fields Here"})}}),a.jsx(te,{enabled:!0,allowSearch:!0,height:500}),a.jsx(ae,{enabled:!0,type:"localStorage",storageKey:E})]})]}),a.jsx(re,{width:520,height:230,title:e("daily_summary_report_dsr2"),gridId:ne,validations:void 0,initialData:x,content:a.jsx(se,{}),toogleFilter:O,onApplyFilters:G,onClose:t=>{t&&y(!1)}})]})})})})};export{xe as default};
