const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CtiCcPbn.js","assets/index-DPq8b99u.js","assets/index-CyPumNks.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-DPq8b99u.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CtiCcPbn.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
