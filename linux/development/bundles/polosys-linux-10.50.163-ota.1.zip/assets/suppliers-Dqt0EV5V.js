import{j as r,r as s}from"./index-DPq8b99u.js";import{P as t}from"./parties-BH1PJxgz.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
