import{j as r,r as t}from"./index-DPq8b99u.js";import{P as s}from"./parties-BH1PJxgz.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
