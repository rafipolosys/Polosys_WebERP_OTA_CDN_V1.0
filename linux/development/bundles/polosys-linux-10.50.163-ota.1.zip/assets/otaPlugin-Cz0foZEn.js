import{gd as g}from"./index-DPq8b99u.js";const r=g("OTAPlugin");export{r as OTAPlugin};
