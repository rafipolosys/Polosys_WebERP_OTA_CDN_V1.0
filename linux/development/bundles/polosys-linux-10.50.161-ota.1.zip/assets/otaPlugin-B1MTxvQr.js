import{gd as g}from"./index-CT82SPhT.js";const r=g("OTAPlugin");export{r as OTAPlugin};
