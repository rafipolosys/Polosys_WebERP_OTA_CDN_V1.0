import{j as r,r as t}from"./index-CT82SPhT.js";import{P as s}from"./parties-Bz5eMikV.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
