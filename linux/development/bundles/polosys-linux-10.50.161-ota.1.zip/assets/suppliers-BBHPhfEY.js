import{j as r,r as s}from"./index-CT82SPhT.js";import{P as t}from"./parties-Bz5eMikV.js";const a=()=>r.jsx(s.Fragment,{children:r.jsx(t,{type:"Supp",gridId:"grd_supp"})});export{a as default};
