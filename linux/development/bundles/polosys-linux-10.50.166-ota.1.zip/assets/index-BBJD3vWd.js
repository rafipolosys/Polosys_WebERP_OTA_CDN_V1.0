const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BVw-6cgu.js","assets/index-qHAgcvKX.js","assets/index-C89kqM68.css"])))=>i.map(i=>d[i]);
import{gd as t,_ as i}from"./index-qHAgcvKX.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BVw-6cgu.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
