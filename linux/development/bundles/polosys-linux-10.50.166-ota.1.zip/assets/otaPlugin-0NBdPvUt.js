import{gd as g}from"./index-qHAgcvKX.js";const r=g("OTAPlugin");export{r as OTAPlugin};
