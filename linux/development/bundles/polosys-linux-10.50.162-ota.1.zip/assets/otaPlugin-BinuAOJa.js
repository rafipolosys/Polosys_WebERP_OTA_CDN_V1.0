import{gd as g}from"./index-DdXqCbCO.js";const r=g("OTAPlugin");export{r as OTAPlugin};
