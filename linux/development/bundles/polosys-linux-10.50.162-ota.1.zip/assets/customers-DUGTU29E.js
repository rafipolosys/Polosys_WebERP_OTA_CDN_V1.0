import{j as r,r as t}from"./index-DdXqCbCO.js";import{P as s}from"./parties-CiRikVgt.js";const a=()=>r.jsx(t.Fragment,{children:r.jsx(s,{type:"Cust",gridId:"grd_cust"})});export{a as default};
